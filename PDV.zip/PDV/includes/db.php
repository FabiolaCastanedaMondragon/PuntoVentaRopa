<?php
$host = 'localhost';  // Dirección del servidor de base de datos
$dbname = 'PDV_Ropa';  // Nombre de la base de datos
$username = 'root';  // Nombre de usuario de la base de datos (cambia según tu configuración)
$password = 'Sacj0412';  // Contraseña de la base de datos (cambia según tu configuración)

// Conexión a la base de datos usando PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Establecer el modo de errores a excepción para facilitar la depuración
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Establecer el charset de la conexión
    $pdo->exec("SET NAMES 'utf8'");
} catch (PDOException $e) {
    // Si hay un error, lo mostramos
    echo "Error de conexión: " . $e->getMessage();
    exit;  // Terminamos el script en caso de error de conexión
}
?>
