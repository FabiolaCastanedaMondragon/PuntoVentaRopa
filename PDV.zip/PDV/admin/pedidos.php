<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION["carrito"])) {
    $_SESSION["carrito"] = [];
}

// Vaciar el carrito si se pulsa el botón
if (isset($_POST['vaciar_carrito'])) {
    $_SESSION["carrito"] = [];
    header("Location: pedidos.php");
    exit();
}

// Obtener productos disponibles
$stmt = $pdo->query("SELECT producto_id, nombre, precio, stock_actual, imagen FROM productos WHERE stock_actual > 0");
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
// Agregar producto al carrito
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["producto_id"])) {
    $producto_id = $_POST["producto_id"];
    $cantidad = intval($_POST["cantidad"] ?? 1);

    // Verificar si producto ya está en el carrito
    $found = false;
    foreach ($_SESSION["carrito"] as &$item) {
        if ($item["producto_id"] == $producto_id) {
            $item["cantidad"] += $cantidad;
            $found = true;
            break;
        }
    }
    unset($item);

    // Si no está en el carrito, lo obtenemos de la BD y lo agregamos
    if (!$found) {
        $stmt = $pdo->prepare("SELECT * FROM productos WHERE producto_id = ?");
        $stmt->execute([$producto_id]);
        $producto = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($producto) {
            $_SESSION["carrito"][] = [
                "producto_id" => $producto["producto_id"],
                "nombre" => $producto["nombre"],
                "precio" => $producto["precio"],
                "cantidad" => $cantidad
            ];
        }
    }

    header("Location: pedidos.php");
    exit();
}



// Calcular totales
$total = 0;
foreach ($_SESSION["carrito"] as $item) {
    $total += $item["precio"] * $item["cantidad"];
}
$iva = $total * 0.16;
$totalConIva = $total + $iva;
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Realizar Pedido</title>
  <link rel="stylesheet" href="../css/st.css" />
</head>
<body>

<aside class="sidebar">
  <h2>Admin PDV</h2>
  <a href="dashboard.php">Dashboard</a>
  <a href="productos.php">Productos</a>
  <a href="pedidos.php" class="active">Pedidos</a>
  <a href="logout.php">Cerrar Sesión</a>
</aside>

<div class="main-content">
  <h1>Punto de Venta - Ropa</h1>

  <section id="productos" class="productos-grid">
    <?php foreach ($productos as $producto): ?>
      <div class="producto-card">
        <img src="../img/<?= htmlspecialchars($producto["imagen"]) ?>" alt="<?= htmlspecialchars($producto["nombre"]) ?>" width="100" height="100" />
        <p><?= htmlspecialchars($producto["nombre"]) ?> - $<?= number_format($producto["precio"], 2) ?> (Stock: <?= $producto["stock_actual"] ?>)</p>
        <form method="POST">
          <input type="hidden" name="producto_id" value="<?= $producto["producto_id"] ?>">
          <input type="number" name="cantidad" value="1" min="1" max="<?= $producto["stock_actual"] ?>" required>
          <button type="submit" class="btn">Agregar al carrito</button>
        </form>
      </div>
    <?php endforeach; ?>
  </section>

  <h2>Carrito de Compras</h2>
  <div id="carrito" class="carrito-box">
    <?php if (!empty($_SESSION["carrito"])): ?>
      <ul>
        <?php foreach ($_SESSION["carrito"] as $item): ?>
          <li><?= $item["cantidad"] ?> x <?= htmlspecialchars($item["nombre"]) ?> - $<?= number_format($item["precio"] * $item["cantidad"], 2) ?></li>
        <?php endforeach; ?>
      </ul>

      <p><strong>Subtotal:</strong> $<?= number_format($total, 2) ?></p>
      <p><strong>IVA (16%):</strong> $<?= number_format($iva, 2) ?></p>
      <p><strong>Total con IVA:</strong> $<?= number_format($totalConIva, 2) ?></p>

      <form action="./pedidos/realizar_pedidos.php" method="POST" style="display:inline-block;">
        <button type="submit" class="btn">Confirmar Pedido</button>
      </form>

      <form method="POST" style="display:inline-block;">
        <input type="hidden" name="vaciar_carrito" value="1">
        <button type="submit" class="btn btn-danger">Vaciar Carrito</button>
      </form>

    <?php else: ?>
      <p>No hay productos en el carrito.</p>
    <?php endif; ?>
  </div>

  <h3>Enviar Nota de Remisión</h3>
  <label for="telefono">Ingresa el número de teléfono (10 dígitos):</label>
  <input type="text" id="telefono" placeholder="Ej. 2345678901">
  <button onclick="enviarPorWhatsapp()">Enviar por WhatsApp</button>
</div>

<script>
  function enviarPorWhatsapp() {
    const telefono = document.getElementById("telefono").value;

    if (!telefono || telefono.length !== 10 || isNaN(telefono)) {
      alert("Por favor, ingresa un número de teléfono válido (10 dígitos).");
      return;
    }

    const productos = <?php echo json_encode($_SESSION["carrito"]); ?>;
    if (productos.length === 0) {
      alert("Tu carrito está vacío.");
      return;
    }

    let mensaje = "🧾 *NOTA DE REMISIÓN* 🧾\n";
    mensaje += "------------------------------\n";

    let resumen = {};
    let subtotal = 0;

    productos.forEach(p => {
      if (!resumen[p.nombre]) {
        resumen[p.nombre] = { cantidad: 0, precio: p.precio };
      }
      resumen[p.nombre].cantidad += parseInt(p.cantidad);
    });

    for (const [nombre, data] of Object.entries(resumen)) {
      let total = data.cantidad * data.precio;
      subtotal += total;
      mensaje += `👕 ${nombre} x ${data.cantidad} = $${total.toFixed(2)}\n`;
    }

    const iva = subtotal * 0.16;
    const total = subtotal + iva;

    mensaje += "------------------------------\n";
    mensaje += `🧾 Subtotal: $${subtotal.toFixed(2)}\n`;
    mensaje += `🧾 IVA (16%): $${iva.toFixed(2)}\n`;
    mensaje += `💰 TOTAL: *$${total.toFixed(2)}*\n`;
    mensaje += "------------------------------\n";
    mensaje += "Gracias por tu compra 🛍️";

    const texto = encodeURIComponent(mensaje);
    window.open(`https://wa.me/52${telefono}?text=${texto}`, '_blank');
  }
</script>

</body>
</html>
