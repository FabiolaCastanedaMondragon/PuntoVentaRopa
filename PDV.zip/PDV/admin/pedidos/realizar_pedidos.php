<?php
session_start();
include '../../includes/db.php';

// Verificar que el carrito no esté vacío
if (!isset($_SESSION["carrito"]) || empty($_SESSION["carrito"])) {
    echo '<div class="mensaje error">Tu carrito está vacío. <a class="boton-volver" href="../pedidos.php">Volver</a></div>';
    exit();
}

// Variables para el ticket
$mostrarTicket = false;
$subtotal_ticket = 0;
$iva_ticket = 0;
$total_ticket = 0;

try {
    // Bandera para evitar reprocesamiento si se recarga la página
    if (!isset($_SESSION['pedido_procesado'])) {
        $pdo->beginTransaction();

        // Calcular totales
        $subtotal = 0;
        foreach ($_SESSION["carrito"] as $item) {
            $subtotal += $item["precio"] * $item["cantidad"];
        }
        $iva = $subtotal * 0.16;
        $total = $subtotal + $iva;

        // Guardar totales para el ticket
        $subtotal_ticket = $subtotal;
        $iva_ticket = $iva;
        $total_ticket = $total;

        // ID del usuario
        $usuario_id = $_SESSION['usuario_id'] ?? 1;

        // Insertar venta
        $stmt = $pdo->prepare("INSERT INTO ventas (subtotal, iva, total, usuario_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$subtotal, $iva, $total, $usuario_id]);
        $venta_id = $pdo->lastInsertId();

        // Insertar detalles de la venta y actualizar stock
        foreach ($_SESSION["carrito"] as $item) {
            $detalleStmt = $pdo->prepare("INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)");
            $detalleSubtotal = $item["cantidad"] * $item["precio"];
            $detalleStmt->execute([$venta_id, $item["producto_id"], $item["cantidad"], $item["precio"], $detalleSubtotal]);
          
            // Actualizar stock
            $stockStmt = $pdo->prepare("UPDATE productos SET stock_actual = stock_actual - ? WHERE producto_id = ? AND stock_actual >= ?");
            $stockStmt->execute([$item["cantidad"], $item["producto_id"], $item["cantidad"]]);
            
            if ($stockStmt->rowCount() === 0) {
                $pdo->rollBack();
                echo '<div class="mensaje error">Error: Stock insuficiente para el producto ID ' . htmlspecialchars($item["producto_id"]) . '.</div>';
                echo '<a class="boton-volver" href="../pedidos.php">Volver</a>';
                exit();
            }
        }

        $pdo->commit();
        $_SESSION['pedido_procesado'] = true; // Marcar como procesado
        $mostrarTicket = true;
    } else {
        // Si ya fue procesado, solo mostrar el ticket
        $mostrarTicket = true;
        foreach ($_SESSION["carrito"] as $item) {
            $subtotal_ticket += $item["precio"] * $item["cantidad"];
        }
        $iva_ticket = $subtotal_ticket * 0.16;
        $total_ticket = $subtotal_ticket + $iva_ticket;
    }

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo '<div class="mensaje error">Error al realizar el pedido: ' . htmlspecialchars($e->getMessage()) . '</div>';
    echo '<a class="boton-volver" href="../pedidos.php">Volver</a>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmar Pedido</title>
    <link rel="stylesheet" href="../../css/confirmacion.css">
    <link rel="stylesheet" href="../../css/confirmacion.css"> <!-- Para el ticket -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f1f1;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            max-width: 700px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px #ccc;
        }
        h2 {
            color: #2c3e50;
        }
        .mensaje {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
        }
        .exito {
            background-color: #e0f7e9;
            color: #2e7d32;
            border: 1px solid #81c784;
        }
        .error {
            background-color: #fdecea;
            color: #c62828;
            border: 1px solid #e57373;
        }
        .boton-volver {
            margin-top: 20px;
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
        }
        .boton-volver:hover {
            background-color: #2980b9;
        }
        /* Estilos para el ticket */
        .confirm-container {
            background-color: #fff;
            max-width: 700px;
            margin: 20px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px #ccc;
        }
        .ticket {
            margin-top: 20px;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 8px;
        }
        .ticket table {
            width: 100%;
            border-collapse: collapse;
        }
        .ticket th, .ticket td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .ticket th {
            background-color: #f2f2f2;
        }
        .total {
            margin-top: 15px;
            text-align: right;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Procesando Pedido...</h2>

    <?php if (isset($e)): ?>
        <div class="mensaje error">Error al realizar el pedido: <?php echo htmlspecialchars($e->getMessage()); ?></div>
        <a class="boton-volver" href="../pedidos.php">Volver</a>
    <?php else: ?>
        <div class="mensaje exito">
            <strong>¡Pedido realizado con éxito!</strong><br>
            Subtotal: $<?php echo number_format($subtotal_ticket, 2); ?><br>
            IVA (16%): $<?php echo number_format($iva_ticket, 2); ?><br>
            <strong>Total: $<?php echo number_format($total_ticket, 2); ?></strong>
        </div>
        
        <div class="confirm-container">
            <h1>✅ Pedido Realizado con Éxito</h1>
            <div class="ticket">
                <h2>🎫 Ticket de Compra</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio Unitario</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION["carrito"] as $item): ?>
                            <?php $item_subtotal = $item["precio"] * $item["cantidad"]; ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item["nombre"]); ?></td>
                                <td>$<?php echo number_format($item["precio"], 2); ?></td>
                                <td><?php echo (int)$item["cantidad"]; ?></td>
                                <td>$<?php echo number_format($item_subtotal, 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="3"><strong>Subtotal:</strong></td>
                            <td><strong>$<?php echo number_format($subtotal_ticket, 2); ?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="3"><strong>IVA (16%):</strong></td>
                            <td><strong>$<?php echo number_format($iva_ticket, 2); ?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="3"><strong>Total:</strong></td>
                            <td><strong>$<?php echo number_format($total_ticket, 2); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <hr>
            <br><br>
            <label for="correo">Ingresa tu correo electrónico:</label>
            <input type="email" id="correo" placeholder="ejemplo@gmail.com" required>
            <button onclick="enviarPorCorreo()" id="btn-correo">Enviar por correo</button>
        </div>

        <a class="boton-volver" href="../pedidos.php">Volver a Pedidos</a>
        
        <script>
        const carrito = <?php echo json_encode($_SESSION['carrito']); ?>;

        function enviarPorCorreo() {
            const correo = document.getElementById("correo").value;
            if (!correo.includes('@')) {
                alert("Correo inválido.");
                return;
            }

            if (carrito.length === 0) {
                alert("El carrito está vacío.");
                return;
            }

            let subtotal = 0;
            let mensaje = "🧾 NOTA DE REMISIÓN 🧾\n------------------------------\n";
            const resumen = {};

            carrito.forEach(p => {
                if (!resumen[p.nombre]) {
                    resumen[p.nombre] = { cantidad: 0, precio: p.precio };
                }
                resumen[p.nombre].cantidad += p.cantidad;
                subtotal += p.precio * p.cantidad;
            });

            Object.entries(resumen).forEach(([nombre, datos]) => {
                const total = datos.cantidad * datos.precio;
                mensaje += `${nombre} x${datos.cantidad} - $${total.toFixed(2)}\n`;
            });

            const iva = subtotal * 0.16;
            const total = subtotal + iva;

            mensaje += `------------------------------\nSubtotal: $${subtotal.toFixed(2)}\nIVA (16%): $${iva.toFixed(2)}\nTOTAL: $${total.toFixed(2)}\n------------------------------\nGracias por su compra.`;

            fetch("enviar_correo.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    correo,
                    mensaje,
                    carrito: Object.entries(resumen).map(([nombre, datos]) => ({
                        nombre,
                        cantidad: datos.cantidad,
                        precio: datos.precio
                    }))
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.mensaje) {
                    alert("Correo enviado correctamente.");
                } else {
                    alert("Error: " + data.error);
                }
            })
            .catch(err => alert("Error en el envío: " + err));
        }
        </script>
        
        <?php 
        // Vaciar carrito solo después de mostrar todo
        unset($_SESSION["carrito"]);
        unset($_SESSION['pedido_procesado']);
        ?>
    <?php endif; ?>
</div>
</body>
</html>