<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';
require 'fpdf1/fpdf.php'; // Asegúrate de que la carpeta y archivo existen

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$correo = $data['correo'] ?? '';
$mensajeTexto = $data['mensaje'] ?? '';
$carrito = $data['carrito'] ?? [];

if (!$correo || !$mensajeTexto || empty($carrito)) {
    http_response_code(400);
    echo json_encode(["error" => "Faltan datos o carrito vacío"]);
    exit;
}

// Generar PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 18);
$pdf->Cell(190, 10, 'Punto de Venta - Ropa', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(190, 10, 'Nota de Remision', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(190, 5, 'Fecha: ' . date('d/m/Y'), 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(90, 10, 'Artículo', 1, 0, 'C');
$pdf->Cell(30, 10, 'Cantidad', 1, 0, 'C');
$pdf->Cell(35, 10, 'Precio Unitario', 1, 0, 'C');
$pdf->Cell(35, 10, 'Subtotal', 1, 1, 'C');

$pdf->SetFont('Arial', '', 12);
$subtotal = 0;
foreach ($carrito as $producto) {
    $totalProducto = $producto['cantidad'] * $producto['precio'];
    $pdf->Cell(90, 10, $producto['nombre'], 1, 0, 'C');
    $pdf->Cell(30, 10, $producto['cantidad'], 1, 0, 'C');
    $pdf->Cell(35, 10, '$' . number_format($producto['precio'], 2), 1, 0, 'C');
    $pdf->Cell(35, 10, '$' . number_format($totalProducto, 2), 1, 1, 'C');
    $subtotal += $totalProducto;
}
$iva = $subtotal * 0.16;
$total = $subtotal + $iva;
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, 'Resumen de Pago', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(190, 8, 'Subtotal: $' . number_format($subtotal, 2), 0, 1, 'C');
$pdf->Cell(190, 8, 'IVA (16%): $' . number_format($iva, 2), 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(190, 10, 'TOTAL A PAGAR: $' . number_format($total, 2), 0, 1, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', 'I', 12);
$pdf->Cell(190, 10, 'Gracias por su compra.¡Esperamos verlo pronto!', 0, 1, 'C');

$pdfFile = 'Nota_Remision_' . time() . '.pdf';
$pdf->Output('F', $pdfFile);

// Enviar correo
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'fabiolaaaaa200418@gmail.com';
    $mail->Password = 'fhvb rxst kqzb aqqw'; // Usa siempre una contraseña de aplicación
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('fabiolaaaaa200418@gmail.com', 'Punto de Venta');
    $mail->addAddress($correo);
    $mail->Subject = 'Nota de Remisión';
    $mail->Body = $mensajeTexto;
    $mail->addAttachment($pdfFile);

    $mail->send();

    unlink($pdfFile);

    echo json_encode(["mensaje" => "Correo enviado con PDF adjunto."]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "Error al enviar: {$mail->ErrorInfo}"]);
}
?>
