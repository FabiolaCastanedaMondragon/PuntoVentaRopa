<?php
session_start();
include '../../includes/db.php';  // Aquí tienes el $pdo (objeto PDO)

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmar Pedido</title>
    <link rel="stylesheet" href="../../css/confirmacion.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f1f1;
            padding: 20px;
        }
        .container {
            background-color: #fff;
            max-width: 700px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px #ccc;
        }
        h2 {
            color: #2c3e50;
        }
        .mensaje {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
        }
        .exito {
            background-color: #e0f7e9;
            color: #2e7d32;
            border: 1px solid #81c784;
        }
        .error {
            background-color: #fdecea;
            color: #c62828;
            border: 1px solid #e57373;
        }
        .boton-volver {
            margin-top: 20px;
            display: inline-block;
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
        }
        .boton-volver:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Procesando Pedido...</h2>

<?php

try {
    // Verificar si hay productos en el carrito
    if (!isset($_SESSION['carrito']) || empty($_SESSION['carrito'])) {
        echo '<div class="mensaje error">El carrito está vacío.</div>';
        exit;
    }

    // Validaciones de stock
    $stmtStock = $pdo->prepare("SELECT stock_actual FROM productos WHERE id = :id");

    foreach ($_SESSION['carrito'] as $id_producto => $cantidad_comprada) {
        $stmtStock->execute([':id' => $id_producto]);
        $fila = $stmtStock->fetch(PDO::FETCH_ASSOC);

        if (!$fila) {
            echo '<div class="mensaje error">Producto con ID '.$id_producto.' no encontrado.</div>';
            exit;
        }

        $stock_actual = $fila['stock_actual'];

        if ($cantidad_comprada > $stock_actual) {
            echo '<div class="mensaje error">Stock insuficiente para el producto con ID '.$id_producto.'.</div>';
            exit;
        }
    }

    // Calcular total del pedido
    $total = 0;
    $stmtPrecio = $pdo->prepare("SELECT precio FROM productos WHERE id = :id");
    foreach ($_SESSION['carrito'] as $id_producto => $cantidad_comprada) {
        $stmtPrecio->execute([':id' => $id_producto]);
        $fila = $stmtPrecio->fetch(PDO::FETCH_ASSOC);
        $precio = $fila['precio'];
        $total += $precio * $cantidad_comprada;
    }

    // Insertar la venta (cabecera)
    $fecha = date("Y-m-d H:i:s");
    $queryVenta = $pdo->prepare("INSERT INTO ventas (fecha, total) VALUES (:fecha, :total)");
    $queryVenta->execute([':fecha' => $fecha, ':total' => $total]);
    $id_venta = $pdo->lastInsertId();

    // Insertar detalle_venta y actualizar stock
    $stmtInsertDetalle = $pdo->prepare(
        "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, precio_unitario) 
         VALUES (:id_venta, :id_producto, :cantidad, :precio_unitario)"
    );

    $stmtUpdateStock = $pdo->prepare(
        "UPDATE productos SET stock_actual = stock_actual - :cantidad WHERE id = :producto_id"
    );

    foreach ($_SESSION['carrito'] as $id_producto => $cantidad_comprada) {
        // Obtener precio
        $stmtPrecio->execute([':id' => $id_producto]);
        $fila = $stmtPrecio->fetch(PDO::FETCH_ASSOC);
        $precio = $fila['precio'];

        // Insertar detalle venta
        $stmtInsertDetalle->execute([
            ':id_venta' => $id_venta,
            ':id_producto' => $id_producto,
            ':cantidad' => $cantidad_comprada,
            ':precio_unitario' => $precio
        ]);

        // Actualizar stock
        $stmtUpdateStock->execute([
            ':cantidad' => $cantidad_comprada,
            ':id_producto' => $id_producto
        ]);
    }

    // Vaciar carrito
    unset($_SESSION['carrito']);

    echo '<div class="mensaje exito">¡Pedido confirmado exitosamente!</div>';

} catch (PDOException $e) {
    echo '<div class="mensaje error">Error en la base de datos: ' . htmlspecialchars($e->getMessage()) . '</div>';
}

?>

    <a href="../../index.php" class="boton-volver">Volver al inicio</a>
</div>
</body>
</html>
