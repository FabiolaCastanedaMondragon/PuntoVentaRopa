<?php
// Lee el contenido de la nota de remisión generada
$nota = file_get_contents("nota_remision.txt");

// Dirección de correo del destinatario
$to = "";  // Cambia esta dirección por la del cliente

// Asunto del correo
$subject = "Nota de remisión";

// Cabecera del correo (remitente)
$headers = "From: tienda@tudominio.com";  // Cambia esta dirección

// Envía el correo
if (mail($to, $subject, $nota, $headers)) {
    echo "✅ Nota enviada por correo.";
} else {
    echo "❌ Error al enviar el correo.";
}
?>
