<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php'; // Asegúrate que este archivo contiene la conexión PDO

// 1. Ventas del día
$stmt = $pdo->prepare("SELECT SUM(total) AS total_ventas FROM ventas WHERE DATE(fecha) = CURDATE()");
$stmt->execute();
$ventasDia = $stmt->fetchColumn() ?? 0;

// 2. Total productos en inventario
$stmt = $pdo->query("SELECT SUM(stock_actual) FROM productos");
$totalInventario = $stmt->fetchColumn() ?? 0;

// 3. Productos con stock crítico (≤ 3)
$stmt = $pdo->prepare("SELECT nombre, stock_actual FROM productos WHERE stock_actual <= 3 ORDER BY stock_actual ASC LIMIT 5");
$stmt->execute();
$productosCriticos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Panel de Administración - Punto de Venta</title>
  <link rel="stylesheet" href="../css/dashboard.css" />
</head>
<body>
  <div class="container">

  <!-- Barra lateral -->
  <aside class="sidebar">
      <h2>Admin PDV</h2>
      <a href="dashboard.php" class="active">Dashboard</a>
      <a href="productos.php" >Productos</a>
      <a href="pedidos.php">Pedidos</a>
      <a href="logout.php">Cerrar Sesión</a>
    </aside>

  <!-- Contenido principal -->
  <div class="main-content">
    <h1 class="dashboard-header">Panel de Administración</h1>

    <section class="cards">
  <div class="card">
    <div class="card-title">Ventas del Día</div>
    <div class="card-value success">$<?php echo number_format($ventasDia, 2); ?></div>
  </div>

  <div class="card">
    <div class="card-title">Total productos en inventario</div>
    <div class="card-value"><?php echo $totalInventario; ?></div>
  </div>

  <div class="card">
    <div class="card-title danger">Productos con Stock Mínimo</div>
    <ul>
      <?php if (count($productosCriticos) > 0): ?>
        <?php foreach ($productosCriticos as $producto): ?>
          <li><?php echo htmlspecialchars($producto['nombre']); ?> (Stock: <?php echo $producto['stock_actual']; ?>)</li>
        <?php endforeach; ?>
      <?php else: ?>
        <li>Sin productos críticos</li>
      <?php endif; ?>
    </ul>
  </div>
</section>

  </div>
</div>
</body>
</html>
