<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

require_once '../includes/db.php';

// Obtener productos
$stmt = $pdo->query("SELECT * FROM productos");
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Productos - Admin PDV</title>
  <link rel="stylesheet" href="../css/productos.css">
  <style>
  
</style>

</head>
<body>
  <div class="container"> <!-- Cambiado de 'content' a 'container' -->

    <aside class="sidebar">
      <h2>Admin PDV</h2>
      <a href="dashboard.php">Dashboard</a>
      <a href="productos.php" class="active">Productos</a>
      <a href="pedidos.php">Pedidos</a>
      <a href="logout.php">Cerrar Sesión</a>
    </aside>

    <div class="main-content">
      <h1>Gestión de Productos</h1>

      <a href="./productos/agregar_producto.php" class="btn-agregar">+ Agregar Producto</a>

      <!-- Mensajes de éxito o error -->
      <?php if (isset($_SESSION['message'])): ?>
          <p class="message"><?= $_SESSION['message']; unset($_SESSION['message']); ?></p>
      <?php endif; ?>

      <table class="tabla-productos">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Stock Actual</th>
            <th>Talla</th>
            <th>Color</th>
            <th>Categoría</th>
            <th>Descripción</th>
            <th>Imagen</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($productos as $producto): ?>
          <tr>
            <td><?= $producto['producto_id'] ?></td>
            <td><?= htmlspecialchars($producto['nombre']) ?></td>
            <td>$<?= number_format($producto['precio'], 2) ?></td>
            <td><?= $producto['stock_actual'] ?></td>
            <td><?= $producto['talla'] ?></td>
            <td><?= $producto['color'] ?></td>
            <td><?= $producto['categoria'] ?></td>
            <td><?= $producto['descripcion'] ?></td>
            <td><img src="../img/<?= $producto['imagen'] ?>" alt="Imagen" width="50"></td>
            <td>
              <a href="./productos/editar_producto.php?id=<?= $producto['producto_id'] ?>" class="btn-editar">Editar</a>
              <a href="./productos/eliminar_producto.php?id=<?= $producto['producto_id'] ?>" class="btn-eliminar" onclick="return confirm('¿Seguro que quieres eliminar este producto?')">Eliminar</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </div>
</body>
</html>
