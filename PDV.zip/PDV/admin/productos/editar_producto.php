
<?php
session_start();
require_once '../../includes/db.php';

// Obtener el producto a editar
if (!isset($_GET['id'])) {
    header("Location: ../productos.php");
    exit();
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM productos WHERE producto_id = ?");
$stmt->execute([$id]);
$producto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$producto) {
    $_SESSION['message'] = "Producto no encontrado.";
    header("Location: ../productos.php");
    exit();
}

// Procesar formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"] ?? '';
    $categoria = $_POST["categoria"] ?? '';
    $talla = $_POST["talla"] ?? '';
    $color = $_POST["color"] ?? '';
    $precio = $_POST["precio"] ?? 0;
    $agregar_stock = $_POST["agregar_stock"] ?? 0;
    $descripcion = $_POST["descripcion"] ?? '';
    $nombreImagen = $producto['imagen'];

    // Validación: solo permitir agregar stock (no restar)
    if ($agregar_stock < 0) {
        $_SESSION['message'] = "No puedes restar stock. Solo se permite agregar.";
        header("Location: editar_producto.php?id=" . $id);
        exit();
    }

    $nuevo_stock = $producto['stock_actual'] + $agregar_stock;

    // Límite máximo de stock
    $stock_maximo = 100; // Puedes ajustarlo según tu lógica
    if ($nuevo_stock > $stock_maximo) {
        $_SESSION['message'] = "No se puede exceder el stock máximo de $stock_maximo unidades.";
        header("Location: editar_producto.php?id=" . $id);
        exit();
    }

    // Procesar imagen nueva (opcional)
    if (isset($_FILES["imagen"]) && $_FILES["imagen"]["error"] === UPLOAD_ERR_OK) {
        $nombreImagen = basename($_FILES["imagen"]["name"]);
        $destino = $_SERVER['DOCUMENT_ROOT'] . "/PDV/img/" . $nombreImagen;
        move_uploaded_file($_FILES["imagen"]["tmp_name"], $destino);
    }

    // Actualizar producto
    $sql = "UPDATE productos SET nombre=?, categoria=?, talla=?, color=?, precio=?, stock_actual=?, descripcion=?, imagen=? WHERE producto_id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $nombre, $categoria, $talla, $color, $precio,
        $nuevo_stock, $descripcion, $nombreImagen, $id
    ]);

    $_SESSION['message'] = "Producto actualizado correctamente. Se añadieron $agregar_stock unidades.";
    header("Location: ../productos.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Producto</title>
  <link rel="stylesheet" href="../../css/agregar_producto.css">
  </head>
<body>
 <!-- Dentro del <body> -->
<div class="main-content">
  <h1>Agregar stock al producto</h1>

  <?php if (isset($_SESSION['message'])): ?>
    <div class="alerta">
      <?= $_SESSION['message']; ?>
      <?php unset($_SESSION['message']); ?>
    </div>
  <?php endif; ?>

  <form action="" method="POST" enctype="multipart/form-data">
    <div class="form-grid">
      <div class="form-group">
        <label>Nombre:</label>
        <input type="text" name="nombre" value="<?= htmlspecialchars($producto['nombre']) ?>" required>
      </div>
      <div class="form-group">
        <label>Precio:</label>
        <input type="number" name="precio" step="0.01" value="<?= $producto['precio'] ?>" required>
      </div>
      <div class="form-group">
        <label>Stock actual:</label>
        <input type="number" value="<?= $producto['stock_actual'] ?>" disabled>
      </div>
      <div class="form-group">
        <label>Agregar stock:</label>
        <input type="number" name="agregar_stock" value="0" min="0" required>
      </div>
      <div class="form-group">
        <label>Talla:</label>
        <input type="text" name="talla" value="<?= htmlspecialchars($producto['talla']) ?>" required>
      </div>
      <div class="form-group">
        <label>Color:</label>
        <input type="text" name="color" value="<?= htmlspecialchars($producto['color']) ?>" required>
      </div>
      <div class="form-group">
        <label>Categoría:</label>
        <input type="text" name="categoria" value="<?= htmlspecialchars($producto['categoria']) ?>" required>
      </div>
      <div class="form-group form-full">
        <label>Descripción:</label>
        <textarea name="descripcion" required><?= htmlspecialchars($producto['descripcion']) ?></textarea>
      </div>
      <div class="form-group form-full">
        <label>Imagen actual:</label><br>
        <img src="../../img/<?= $producto['imagen'] ?>" alt="Imagen actual" width="100">
      </div>
      <div class="form-group form-full">
        <label>Subir nueva imagen (opcional):</label>
        <input type="file" name="imagen">
      </div>
    </div>
    <br>
    <button type="submit" class="btn-agregar">Guardar Cambios</button>
  </form>
</div>

</body>
</html>
