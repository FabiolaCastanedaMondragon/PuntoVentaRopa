<?php
session_start();
require_once '../../includes/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Intentar eliminar el producto
        $stmt = $pdo->prepare("DELETE FROM productos WHERE producto_id = ?");
        $stmt->execute([$id]);

        $_SESSION['message'] = "Producto eliminado correctamente.";
    } catch (PDOException $e) {
        if ($e->getCode() == '23000') {
            // Error por restricción de clave foránea
            $_SESSION['message'] = "❌ No se puede eliminar el producto porque ya ha sido vendido.";
        } else {
            // Otro error
            $_SESSION['message'] = "❌ Error al eliminar el producto: " . $e->getMessage();
        }
    }
}

header("Location: ../productos.php");
exit();
?>
