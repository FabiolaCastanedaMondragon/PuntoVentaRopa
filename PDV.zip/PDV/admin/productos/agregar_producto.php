<?php
session_start();
include '../../includes/db.php'; // Asegúrate de que este archivo defina correctamente $pdo

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar existencia de campos
    $nombre = $_POST["nombre"] ?? '';
    $categoria = $_POST["categoria"] ?? '';
    $talla = $_POST["talla"] ?? '';
    $color = $_POST["color"] ?? '';
    $precio = $_POST["precio"] ?? 0;
    $stock_actual = $_POST["stock_actual"] ?? 0;
    $stock_minimo = $_POST["stock_minimo"] ?? 0;
    $stock_maximo = $_POST["stock_maximo"] ?? 0;
    $descripcion = $_POST["descripcion"] ?? '';

    // Validaciones de stock
    if ($stock_minimo > $stock_maximo) {
        $_SESSION['message'] = "El stock mínimo no puede ser mayor que el stock máximo.";
        header("Location: agregar_producto.php");
        exit();
    }

    if ($stock_actual < $stock_minimo || $stock_actual > $stock_maximo) {
        $_SESSION['message'] = "El stock actual debe estar entre el mínimo y el máximo.";
        header("Location: agregar_producto.php");
        exit();
    }

    // Validar y mover imagen
    if (isset($_FILES["imagen"]) && $_FILES["imagen"]["error"] === UPLOAD_ERR_OK) {
        $nombreImagen = basename($_FILES["imagen"]["name"]);
        $destino = $_SERVER['DOCUMENT_ROOT'] . "/PDV/img/" . $nombreImagen;

        if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $destino)) {
            // Insertar en la base de datos
            $sql = "INSERT INTO productos (nombre, categoria, talla, color, precio, stock_actual, stock_minimo, stock_maximo, descripcion, imagen)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([ 
                $nombre, $categoria, $talla, $color, $precio,
                $stock_actual, $stock_minimo, $stock_maximo,
                $descripcion, $nombreImagen
            ]);

            $_SESSION['message'] = "Producto agregado correctamente.";
            header("Location: ../productos.php");
            exit();
        } else {
            $_SESSION['message'] = "Error al mover la imagen.";
            header("Location: agregar_producto.php");
            exit();
        }
    } else {
        $_SESSION['message'] = "Error al subir la imagen. Código: " . $_FILES["imagen"]["error"];
        header("Location: agregar_producto.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Agregar Producto</title>
  <link rel="stylesheet" href="../../css/agregar_producto.css">
  <style>
    .alerta {
      background-color: #ffe5e5;
      color: #b30000;
      padding: 12px;
      margin: 10px 0;
      border: 1px solid #b30000;
      border-radius: 5px;
      text-align: center;
      font-weight: bold;
    }
  </style>
</head>
<body>

  <div class="main-content">
    <h1>Agregar nuevo producto</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alerta">
          <?= $_SESSION['message']; ?>
          <?php unset($_SESSION['message']); ?>
        </div>
    <?php endif; ?>

    <form action="agregar_producto.php" method="POST" enctype="multipart/form-data">
      <div>
        <label>Nombre:</label><br>
        <input type="text" name="nombre" required>
      </div>
      <div>
        <label>Precio:</label><br>
        <input type="number" name="precio" step="0.01" required>
      </div>
      <div>
        <label>Stock actual:</label><br>
        <input type="number" name="stock_actual" required>
      </div>
      <div>
        <label>Stock mínimo:</label><br>
        <input type="number" name="stock_minimo" required>
      </div>
      <div>
        <label>Stock máximo:</label><br>
        <input type="number" name="stock_maximo" required>
      </div>
      <div>
        <label>Talla:</label><br>
        <input type="text" name="talla" required>
      </div>
      <div>
        <label>Color:</label><br>
        <input type="text" name="color" required>
      </div>
      <div>
        <label>Categoría:</label><br>
        <input type="text" name="categoria" required>
      </div>
      <div>
        <label>Descripción:</label><br>
        <textarea name="descripcion" required></textarea>
      </div>

      <div class="imagen-container">
        <label>Imagen:</label><br>
        <input type="file" name="imagen" required>
      </div>

      <button type="submit" class="btn-agregar">Guardar Producto</button>
    </form>
  </div>

</body>
</html>
