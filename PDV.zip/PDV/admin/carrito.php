<?php
// Lee el JSON enviado desde el frontend
$data = json_decode(file_get_contents("php://input"), true);

// Verifica si llegaron datos
if (!$data || !is_array($data)) {
    echo "Error: Carrito vacío o formato inválido.";
    exit;
}

// Calcula el subtotal
$subtotal = 0;
foreach ($data as $item) {
    $subtotal += $item["precio"] * $item["cantidad"];
}

// Calcula IVA (16%) y total
$iva = $subtotal * 0.16;
$total = $subtotal + $iva;

// Construye la nota de remisión
$nota = "NOTA DE REMISIÓN\n";
$nota .= "-------------------------\n";

foreach ($data as $item) {
    $linea = "{$item['nombre']} x {$item['cantidad']} = $" . ($item['precio'] * $item['cantidad']) . "\n";
    $nota .= $linea;
}

$nota .= "-------------------------\n";
$nota .= "Subtotal: $" . number_format($subtotal, 2) . "\n";
$nota .= "IVA (16%): $" . number_format($iva, 2) . "\n";
$nota .= "TOTAL: $" . number_format($total, 2) . "\n";

// Guarda la nota en un archivo de texto
file_put_contents("nota_remision.txt", $nota);

// Muestra mensaje al usuario
echo "✅ Nota de remisión generada correctamente.";
?>
