/pdv-ropa/
│
│
├── /admin/                      ← Carpeta exclusiva del administrador
│   ├── dashboard.php                 ← Panel de control (dashboard)
│   ├──login
│   ├── productos.php             ← Gestión de productos
│   ├── pedidos.php               ← Gestión de pedidos
│   ├── merma.php                 ← Registro de merma
│   ├── reportes.php              ← Reportes y notas
├── /client/                      ← Carpeta exclusiva del administrador
│   ├──carrito.php
│   ├──confirmacion.php
│   ├──estado-pedido.php
│   ├──index.php
│   ├──login.php
│   ├──pago.php
│   ├──productos.php
│
│
├── /css/                        ← Hojas de estilo
│
├── /img/                        ← Imágenes de productos
│
├── /includes/
│   ├── db.php              ← Conexión a la base de datos
│   ├── funciones.php       ← Funciones reutilizables (por ejemplo, calcular IVA, validación de stock)
│   ├── session.php         ← Verificación de sesión para el login

